package com.raj.service;

import java.util.List;

import com.raj.model.User;

public interface UserService {

	User removeById(int id);
	void add(User user);
	List<User> getAll();
	
	void update(User user);
}
